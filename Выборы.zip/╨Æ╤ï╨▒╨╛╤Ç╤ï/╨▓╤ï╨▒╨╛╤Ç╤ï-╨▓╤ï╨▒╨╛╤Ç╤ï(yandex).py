N = int(input()) 
votes_for_Andrey_by_regions = {}
votes_for_Boris_by_regions = {}
sum_votes_by_regions = {}

for region in range(1, N + 1):
    andrey, boris = map(int, input().split())
    votes_for_Andrey_by_regions[region] = andrey
    votes_for_Boris_by_regions[region] = boris
    sum_votes_by_regions[region] = 2*andrey + boris


sorted_regions = sorted(sum_votes_by_regions.keys(), key=lambda x: sum_votes_by_regions[x], reverse=True)


regions = 0
res_votes = 0
extracted_votes = 0
total_Andrey_votes = sum(votes_for_Andrey_by_regions.values())

for region in sorted_regions:
    res_votes += votes_for_Andrey_by_regions[region] + votes_for_Boris_by_regions[region]
    extracted_votes += votes_for_Andrey_by_regions[region]
    regions += 1
    if res_votes > total_Andrey_votes - extracted_votes:
        break

print(regions)
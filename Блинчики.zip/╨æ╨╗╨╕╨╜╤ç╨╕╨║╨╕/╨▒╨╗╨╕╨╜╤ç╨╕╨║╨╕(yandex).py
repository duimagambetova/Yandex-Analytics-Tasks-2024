p=float(input())

res = 1/(p**2*(1-p))

print(res)
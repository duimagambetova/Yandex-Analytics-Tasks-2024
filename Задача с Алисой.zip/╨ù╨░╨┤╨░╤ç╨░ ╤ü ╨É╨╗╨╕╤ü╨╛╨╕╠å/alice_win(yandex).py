def is_prime(num):
    if num <= 1:
        return False
    if num <= 3:
        return True
    if num % 2 == 0 or num % 3 == 0:
        return False
    i = 5
    while i * i <= num:
        if num % i == 0 or num % (i + 2) == 0:
            return False
        i += 6
    return True

def next_prime(n):
    prime_candidate = n + 1
    while not is_prime(prime_candidate):
        prime_candidate += 1
    return prime_candidate

def can_alice_win(n, k):
    nearest_prime = next_prime(n)
    if (nearest_prime - n) % (k + 1) == 0:
        return "NO"
    else:
        return "YES"

n, k = map(int, input().split())
result = can_alice_win(n, k)
print(result)